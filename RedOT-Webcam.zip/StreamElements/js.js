let fd = {};
const queue = [];
let busy = false;
let burst = 0;            // frames de chama turbinada (alerta)

const $ = (id) => document.getElementById(id);

window.addEventListener('onWidgetLoad', (obj) => {
  fd = obj.detail.fieldData || {};
  const root = document.documentElement.style;
  if (fd.fireColor) root.setProperty('--fire', fd.fireColor);
  if (fd.goldColor) root.setProperty('--gold', fd.goldColor);
  if (fd.logoSize) root.setProperty('--logo-w', fd.logoSize);
  if (fd.partnerSize) root.setProperty('--partner-h', fd.partnerSize);
  if (fd.logoImage) $('logo-img').src = fd.logoImage;
  if (fd.partnerImage) $('partner-img').src = fd.partnerImage;
  if (fd.showPartner === 'no') $('cam').classList.add('no-partner');

  $('follow-label').textContent = fd.followLabel || 'ÚLTIMO SEGUIDOR:';
  $('donate-label').textContent = fd.donateLabel || 'ÚLTIMO DONATE:';

  // valores salvos na sessão do StreamElements
  const s = (obj.detail.session && obj.detail.session.data) || {};
  const f = s['follower-latest'];
  const t = s['tip-latest'];
  if (f && f.name) $('follow-name').textContent = f.name;
  if (t && t.name) $('donate-name').textContent = donateText(t.name, t.amount);

  startFx();
});

window.addEventListener('onEventReceived', (obj) => {
  const l = obj.detail.listener;
  const e = obj.detail.event || {};

  // botões de teste no editor do StreamElements
  if (l === 'widget-button') {
    if (e.field === 'testFollow') follow('Aventureiro');
    if (e.field === 'testDonate') donate('DoadorRed', 25, 'Bora RedOT!');
    return;
  }
  const name = e.name || e.displayName || 'Aventureiro';
  if (l === 'follower-latest') follow(name);
  else if (l === 'tip-latest') donate(name, e.amount, e.message);
  else if (l === 'subscriber-latest' && fd.subAlerts !== 'no') push({ title: e.gifted ? 'SUB PRESENTEADO' : 'NOVO SUB', name });
  else if (l === 'cheer-latest' && fd.subAlerts !== 'no') push({ title: `${e.amount} BITS`, name });
  else if (l === 'raid-latest' && fd.subAlerts !== 'no') push({ title: `RAID DE ${e.amount}`, name });
});

function money(v) {
  const n = Number(v);
  if (!isFinite(n)) return '';
  return `${fd.currency ?? 'R$'} ${n.toLocaleString('pt-BR', { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 })}`;
}
function donateText(name, amount) {
  return fd.showAmount === 'no' || amount == null ? name : `${name} · ${money(amount)}`;
}

function follow(name) {
  push({ title: fd.followAlertTitle || 'NOVO SEGUIDOR', name, after: () => setValue('follow-name', name) });
}
function donate(name, amount, message) {
  const title = (fd.donateAlertTitle || 'DONATE') + (amount != null && fd.showAmount !== 'no' ? ` · ${money(amount)}` : '');
  push({ title, name, msg: fd.showMessage === 'no' ? '' : (message || ''), after: () => setValue('donate-name', donateText(name, amount)) });
}

function setValue(id, text) {
  const el = $(id);
  el.textContent = text;
  el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
}

function push(a) {
  queue.push(a);
  if (!busy) next();
}

function next() {
  const a = queue.shift();
  const cam = $('cam');
  if (!a) { busy = false; return; }
  busy = true;
  if (fd.alerts === 'no') { if (a.after) a.after(); return next(); }
  $('alert-title').textContent = a.title;
  $('alert-name').textContent = a.name;
  $('alert-msg').textContent = a.msg || '';
  cam.classList.add('alerting');
  const secs = fd.alertDuration || 6;
  burst = secs * 60;
  setTimeout(() => {
    cam.classList.remove('alerting');
    if (a.after) a.after();
    setTimeout(next, 900);
  }, secs * 1000);
}

/* ---------------- fogo, brasas e bolas de fogo ---------------- */
function sprite(stops, size = 64) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  stops.forEach(([o, col]) => grd.addColorStop(o, col));
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  return c;
}

function startFx() {
  const cv = $('fx');
  const ctx = cv.getContext('2d');
  const cs = getComputedStyle(document.documentElement);
  const fire = (cs.getPropertyValue('--fire').trim() || '#ff4a1c');

  // paleta de chama: núcleo amarelo → laranja → cor do fogo → fumaça escura
  const flame = [
    sprite([[0, '#fff6d0'], [.3, '#ffd36acc'], [1, '#ffb00000']]),
    sprite([[0, '#ffb347'], [.4, '#ff7a1fbb'], [1, '#ff4a1c00']]),
    sprite([[0, fire], [.45, fire + 'aa'], [1, fire + '00']]),
    sprite([[0, '#5a0d06aa'], [1, '#2a050300']]),
  ];
  const ember = sprite([[0, '#fffbe6'], [.2, '#ffcf5a'], [.5, '#ff6a1a66'], [1, '#ff3a0000']], 32);

  let W = 0, H = 0, dpr = 1, fr, lg, bar;
  const measure = () => {
    dpr = window.devicePixelRatio || 1;
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    const base = cv.getBoundingClientRect();
    const rel = (el) => { const r = el.getBoundingClientRect(); return { x: r.left - base.left, y: r.top - base.top, w: r.width, h: r.height }; };
    fr = rel($('frame'));
    lg = rel($('logo-img'));
    bar = rel($('bar'));
  };
  measure();
  window.addEventListener('resize', measure);
  $('logo-img').addEventListener('load', measure);

  const parts = [];
  const density = (fd.emberDensity ?? 5) / 5;
  const flameDensity = (fd.flameDensity ?? 5) / 5;

  // ponto aleatório na faixa dourada da moldura
  const framePoint = () => {
    const { x, y, w, h } = fr;
    const t = Math.random() * (2 * w + 2 * h);
    if (t < w) return [x + t, y];
    if (t < w + h) return [x + w, y + t - w];
    if (t < 2 * w + h) return [x + 2 * w + h - t, y + h];
    return [x, y + 2 * (w + h) - t];
  };

  const spawnEmber = (power) => {
    const [x, y] = Math.random() < .15
      ? [bar.x + Math.random() * bar.w, bar.y + bar.h * .2]   // algumas saem da barra
      : framePoint();
    parts.push({
      kind: 'ember', x, y,
      vx: (Math.random() - .5) * .5 * power, vy: -(Math.random() * .7 + .25) * power,
      size: (Math.random() * 3 + 2) * (W / 1000) * (power > 1 ? 1.4 : 1),
      life: 1, decay: Math.random() * .006 + .004, seed: Math.random() * 1000,
    });
  };

  // chamas atrás do logo (em cima da pedra/raposa), como no banner
  const spawnFlame = (power) => {
    const a = Math.PI * (1.15 + Math.random() * .7);           // arco superior (pedra + raposa)
    const cx = lg.x + lg.w / 2, cy = lg.y + lg.h * .5;
    const x = cx + Math.cos(a) * lg.w * .36;
    const y = cy + Math.sin(a) * lg.h * .44 + lg.h * .06;
    parts.push({
      kind: 'flame', x, y,
      vx: Math.cos(a) * .18, vy: -(Math.random() * .5 + .45) * power,
      size: (Math.random() * 14 + 14) * (W / 1000) * (.85 + power * .25),
      life: 1, decay: Math.random() * .01 + .018, seed: Math.random() * 1000,
    });
  };

  // bolas de fogo correndo pela barra (no lugar dos planetas do DeusOT)
  const orbs = [0, .37, .71].map((p, i) => ({ p, speed: .00055 + i * .00012, size: 1 + (i % 2) * .4 }));

  let t = 0, last = 0, accE = 0, accF = 0;
  (function loop(now = 0) {
    const dt = last ? Math.min((now - last) / 16.67, 3) : 1;
    last = now; t += dt;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    const boosting = burst > 0;
    if (boosting) burst = Math.max(0, burst - dt);
    const power = boosting ? 1.7 : 1;

    accE += (2 * (fr.w + fr.h)) / 900 * .55 * density * (boosting ? 2.5 : 1) * dt;
    while (accE >= 1) { spawnEmber(power); accE--; }
    if (fd.logoFlames !== 'no') {
      accF += 2.2 * flameDensity * (boosting ? 2.6 : 1) * dt;
      while (accF >= 1) { spawnFlame(power); accF--; }
    }

    ctx.globalCompositeOperation = 'lighter';
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      p.x += (p.vx + Math.sin((t + p.seed) * .05) * (p.kind === 'flame' ? .35 : .4)) * dt;
      p.y += p.vy * dt;
      p.vy -= (p.kind === 'flame' ? .012 : .003) * dt;
      p.life -= p.decay * dt;
      if (p.life <= 0) { parts.splice(i, 1); continue; }
      if (p.kind === 'ember') {
        const s = p.size * (.5 + p.life * .5) * (1 + Math.sin((t + p.seed) * .3) * .25);
        ctx.globalAlpha = Math.min(1, p.life * 2);
        ctx.drawImage(ember, p.x - s * 2, p.y - s * 2, s * 4, s * 4);
      } else {
        const stage = p.life > .8 ? 0 : p.life > .55 ? 1 : p.life > .25 ? 2 : 3;
        if (stage === 3) ctx.globalCompositeOperation = 'source-over';
        const s = p.size * (stage === 3 ? 1.3 : .6 + (1 - p.life) * .7);
        ctx.globalAlpha = (stage === 3 ? p.life * 1.2 : .38) * (stage === 0 ? .8 : 1);
        ctx.setTransform(dpr, 0, 0, dpr, p.x * dpr, p.y * dpr);
        ctx.drawImage(flame[stage], -s * .45, -s * .7, s * .9, s * 1.4);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.globalCompositeOperation = 'lighter';
      }
    }

    // bolas de fogo com rastro correndo na borda de cima da barra
    if (fd.barOrbs !== 'no') {
      const y0 = bar.y + bar.h * .02;
      for (const o of orbs) {
        o.p = (o.p + o.speed * dt * (boosting ? 3 : 1)) % 1;
        const x = bar.x + o.p * bar.w;
        const fade = Math.min(1, o.p * 12, (1 - o.p) * 12);
        const r = 9 * (W / 1000) * o.size;
        for (let k = 10; k >= 0; k--) {
          const tx = x - k * r * .55, ty = y0 + Math.sin((t * .08) + k * .5) * r * .12;
          ctx.globalAlpha = fade * (1 - k / 11) * .5;
          ctx.drawImage(flame[k < 3 ? 1 : 2], tx - r * (1 - k / 16), ty - r * (1 - k / 16), r * 2 * (1 - k / 16), r * 2 * (1 - k / 16));
        }
        ctx.globalAlpha = fade;
        ctx.drawImage(ember, x - r * 1.6, y0 - r * 1.6, r * 3.2, r * 3.2);
        if (Math.random() < .15 * dt) parts.push({ kind: 'ember', x, y: y0, vx: -.3, vy: -Math.random() * .6 - .2, size: 2 * (W / 1000), life: .8, decay: .02, seed: Math.random() * 1000 });
      }
    }

    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    requestAnimationFrame(loop);
  })();
}
